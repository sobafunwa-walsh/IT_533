import json # importing the json module as seen in lecture

#1 created an empty list to store sales data
sales_data = []

#2. opening the CSV file titled "SalesJan2009.csv" with intent to convert to JSON; fields:keys are addressed further down
csv_file = open("text_files/SalesJan2009.csv")


#3 Goal is to process line-by-line, and create dictonaries to append to the sales_data list and clean up the data

for tmp_line in csv_file:
    # removed white spaces and splitting each line by commas, and removing any extra quote characters
    line = tmp_line.strip().replace('"', '').split(",")


# created a dictionary for each sale record and appending each to the sales_data list, using the specified keys that were shared in lecture
# used formatting apprach as seen on page 222 of the textbook (6th edition)
    sale_record = {
        "Transaction_date": line[0].split(" ")[0], # splitting date and time, keeping only date to reflect stated heading field (trasaction_DATE)
        "Product": line[1],
        "Price": (line[2]),
        "Payment_Type": line[3],
        "Name": line[4],
        "City": line[5],
        "State": line[6],
        "Country": line[7]
    }
    sales_data.append(sale_record) # appending each sale_record dictionary to the sales_data list

#4 converting the sales_data list to JSON format and writing to the transaction_data.json file
json_file = open("text_files/transaction_data.json", "w")
json.dump(sales_data, json_file, indent=4)
json_file.close()

print(sales_data)